angular.module('starter.services', [])

//Os serviços vão aqui

.factory('firebaseData',function($firebase){
	var config = {
    apiKey: "AIzaSyAXi9gkhvCf7St4yeriVENtDjp1fkvNGLw",
    authDomain: "moto-fast-1a599.firebaseapp.com",
    databaseURL: "https://moto-fast-1a599.firebaseio.com",
    storageBucket: "moto-fast-1a599.appspot.com",
    messagingSenderId: "629918605785"
  };
  firebase.initializeApp(config);

  var ref = firebase.database().ref();

  return {
  	ref: function(){
  		return ref;
  	},
 	refUsuarios : function(){
 		return ref.child('usuarios');
 	},
 	refProfissionais: function(){
 		return ref.child('profissionais');
 	}
  }
})