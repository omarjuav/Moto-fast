angular.module('starter.controllers', [])

  .controller('UsuarioCtrl', function ($scope,firebaseData,$firebaseArray,$rootScope) {
    $scope.usuarios = $firebaseArray(firebaseData.refUsuarios())
    $scope.addUsuario = function (e) {
      $scope.usuarios.$add({
        nome: $scope.nome,
        end_atual: $scope.end_atual,
        end_destino: $scope.end_destino,
        ref: $scope.ref,
        tel: $scope.tel
      });
      $scope.nome = "";
      $scope.end_atual = "";
      $scope.end_destino = "";
      $scope.ref = "";
      $scope.tel = 0;
      
    };
  })

  .controller('ProfissionalCtrl', function ($scope,firebaseData,$firebaseArray,$rootScope) {
    $scope.profissional = $firebaseArray(firebaseData.refProfissionais())
    $scope.addProfissional = function (e) {
      $scope.profissionais.$add({
        nome: $scope.nome,
        valor: $scope.valor
      });
      $scope.user = "";
      $scope.senha = "";
    };
  })

 